public interface IScannerFactory
{
    IAPA CreateAPA();
    IMLA CreateMLA();
}
