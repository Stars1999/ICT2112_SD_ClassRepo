using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ICT2106WebApp.Pages
{
    public class LoggerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
